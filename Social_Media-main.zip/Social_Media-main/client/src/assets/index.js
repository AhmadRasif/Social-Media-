import NoProfile from "./userprofile.png";

export { NoProfile };
